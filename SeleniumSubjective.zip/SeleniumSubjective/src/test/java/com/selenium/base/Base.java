package com.selenium.base;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

//import com.selenium.utilities.ExcelReader;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Base {
	public static WebDriver driver;
	public static Logger log = Logger.getLogger("devpinoyLogger");
	//public static ExcelReader excel = new ExcelReader(
			//System.getProperty("user.dir") + "\\src\\test\\resources\\excel\\testdata.xlsx");

	//@BeforeSuite
	public static void setUp() {
		if (driver == null) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();

		}
		
		driver.get("http://demo.guru99.com/test/newtours/register.php ");

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	//@AfterSuite
	public static void tearDown() {
		if (driver != null) {
			driver.quit();
		}
	}
}
