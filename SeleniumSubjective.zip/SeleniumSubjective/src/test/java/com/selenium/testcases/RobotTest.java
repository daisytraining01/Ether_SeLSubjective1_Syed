package com.selenium.testcases;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
 
import org.openqa.selenium.By;
import com.selenium.base.Base;

public class RobotTest extends Base{

	public static void main(String[] args) throws InterruptedException, AWTException {
		// TODO Auto-generated method stub
		setUp();
		driver.navigate().to("http://www.amazon.in");
		Thread.sleep(10000);
		//driver.findElement(By.linkText("Mobiles")).click();
		Robot robot = new Robot();
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_DOWN);
		Thread.sleep(4000);
		robot.keyPress(KeyEvent.VK_TAB);
		Thread.sleep(4000);
		System.out.println("a");
		robot.keyPress(KeyEvent.VK_TAB);
		Thread.sleep(4000);
		System.out.println("b");
		robot.keyPress(KeyEvent.VK_TAB);
		Thread.sleep(4000);
		System.out.println("c");
		robot.mouseMove(30,100);
		Thread.sleep(4000);
		System.out.println("d");
		tearDown();
	}

}
