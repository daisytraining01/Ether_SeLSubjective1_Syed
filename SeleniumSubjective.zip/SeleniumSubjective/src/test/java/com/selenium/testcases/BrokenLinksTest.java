package com.selenium.testcases;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.selenium.base.Base;

public class BrokenLinksTest extends Base{
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		setUp();
		driver.navigate().to("https://maveric-systems.com");
		Thread.sleep(10000);
		
		List<WebElement> links = driver.findElements(By.tagName("a"));
		 System.out.println(links.size());
		 for (int i = 1; i<links.size(); i++)
		 {
			 System.out.println(links.get(i).getAttribute("href"));
			 String link = links.get(i).getAttribute("href");
			 if(link == null || link.isEmpty()){
				 System.out.println("Link is Empty Or null");
			 }
			 if(!link.startsWith("https://maveric-systems.com")) {
				 System.out.println("This link belongs to different domain");
			 }
			 try {
	                HttpURLConnection connection = (HttpURLConnection)(new URL(link).openConnection());
	                
	                connection.setRequestMethod("HEAD");
	                
	                connection.connect();
	                
	                int respCode = connection.getResponseCode();
	                
	                if(respCode >= 400){
	                    System.out.println(link+" is a broken link");
	                }
	                    
	            } catch (MalformedURLException e) {
	                // TODO Auto-generated catch block
	                e.printStackTrace();
	            } catch (IOException e) {
	                // TODO Auto-generated catch block
	                e.printStackTrace();
	            }
	        }
		 tearDown();
		 //System.out.println(links.get(i).getText());
		 }
	
}
