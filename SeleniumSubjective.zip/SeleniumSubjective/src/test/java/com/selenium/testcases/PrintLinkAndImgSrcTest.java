package com.selenium.testcases;


import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.selenium.base.Base;
import com.selenium.utilities.TestUtil;

public class PrintLinkAndImgSrcTest extends Base{

	public static void main(String[] args) throws Throwable {
		// TODO Auto-generated method stub
		setUp();
		driver.navigate().to("https://wordpress.com/?aff=58022&cid=8348279");
		Thread.sleep(10000);
		Actions action = new Actions(driver);
		WebElement products = driver.findElement(By.xpath("//button[contains(text(),'Products')]"));
		WebElement blogs = driver.findElement(By.xpath("//a[@class='x-dropdown-link x-link'][contains(text(),'Blogs')]"));
		//products
		action.moveToElement(products).perform();
		Thread.sleep(5000);
		getLinks(blogs);

		action.moveToElement(driver.findElement(By.xpath("//button[contains(text(),'Products')]"))).perform();
		Thread.sleep(5000);
		getLinks(driver.findElement(By.xpath("//a[@class='x-dropdown-link x-link'][contains(text(),'Websites')]")));
		
		action.moveToElement(driver.findElement(By.xpath("//button[contains(text(),'Products')]"))).perform();
		Thread.sleep(5000);
		getLinks(driver.findElement(By.xpath("//a[@class='x-dropdown-link x-link'][contains(text(),'Domains')]")));
		
		action.moveToElement(driver.findElement(By.xpath("//button[contains(text(),'Products')]"))).perform();
		Thread.sleep(5000);
		getLinks(driver.findElement(By.xpath("//a[@class='x-dropdown-link x-link'][contains(text(),'eCommerce')]")));
		
		action.moveToElement(driver.findElement(By.xpath("//button[contains(text(),'Products')]"))).perform();
		Thread.sleep(5000);
		getLinks(driver.findElement(By.xpath("//a[@class='x-dropdown-link x-link'][contains(text(),'Hosted Solutions')]")));
		
		action.moveToElement(driver.findElement(By.xpath("//button[contains(text(),'Products')]"))).perform();
		Thread.sleep(5000);
		getLinks(driver.findElement(By.xpath("//a[@class='x-dropdown-link x-link x-external-link']")));
		
		//features
		action.moveToElement(driver.findElement(By.xpath("//button[contains(text(),'Features')]"))).perform();
		Thread.sleep(5000);
		getLinks(driver.findElement(By.xpath("//a[@class='x-dropdown-link x-link'][contains(text(),'Overview')]")));
		
		action.moveToElement(driver.findElement(By.xpath("//button[contains(text(),'Features')]"))).perform();
		Thread.sleep(5000);
		getLinks(driver.findElement(By.xpath("//a[@class='x-dropdown-link x-link'][contains(text(),'Themes')]")));
		
		action.moveToElement(driver.findElement(By.xpath("//button[contains(text(),'Features')]"))).perform();
		Thread.sleep(5000);
		getLinks(driver.findElement(By.xpath("//a[@class='x-dropdown-link x-link'][contains(text(),'Plugins')]")));
		
		action.moveToElement(driver.findElement(By.xpath("//button[contains(text(),'Features')]"))).perform();
		Thread.sleep(5000);
		getLinks(driver.findElement(By.xpath("//a[@class='x-dropdown-link x-link'][contains(text(),'Google Apps')]")));
        
		//Resources
		action.moveToElement(driver.findElement(By.xpath("//button[contains(text(),'Resources')]"))).perform();
		Thread.sleep(5000);
		getLinks(driver.findElement(By.xpath("//a[@class='x-dropdown-link x-link'][contains(text(),'Support')]")));
		
		action.moveToElement(driver.findElement(By.xpath("//button[contains(text(),'Resources')]"))).perform();
		Thread.sleep(5000);
		getLinks(driver.findElement(By.xpath("//a[@class='x-dropdown-link x-link'][contains(text(),'News')]")));
		
		action.moveToElement(driver.findElement(By.xpath("//button[contains(text(),'Resources')]"))).perform();
		Thread.sleep(5000);
		getLinks(driver.findElement(By.xpath("//a[@class='x-dropdown-link x-link'][contains(text(),'Expert Tips')]")));
		//Thread.sleep(5000);
           // }
        tearDown();
	}
	public static void getLinks(WebElement element) throws Throwable {
		element.click();
		Thread.sleep(10000);
		TestUtil util = new TestUtil();
		//TestUtil.writeToExcel(0, 0, "LinkText");
		List<String> linkText = new ArrayList<String>();
		//linkText.add("naser");
		List<WebElement> links = driver.findElements(By.tagName("a"));
		List<WebElement> allImages = driver.findElements(By.tagName("img"));
		 System.out.println(links.size());
		 for (int i = 1; i<links.size(); i++)
		 {
			 System.out.println(links.get(i).getAttribute("href"));
			if(links.get(i).getText() != null) {
				linkText.add(links.get(i).getText());
			}
			 //TestUtil.writeToExcel(i, 0, links.get(i).getText());
		 //System.out.println(links.get(i).getText());
		 }
		 for(int listCount = 0; listCount<linkText.size(); listCount++) {
			 util.writeToExcel("sheet1",listCount, 0, linkText.get(listCount));
		 }
		 for (int j = 1; j<allImages.size(); j++)
		 {
			 System.out.println(allImages.get(j).getAttribute("src"));
		 //System.out.println(links.get(i).getText());
		 }
		 driver.navigate().to("https://wordpress.com/?aff=58022&cid=8348279");
			Thread.sleep(10000);
			driver.findElement(By.xpath("//button[contains(text(),'Products')]"));
		
	}

}
