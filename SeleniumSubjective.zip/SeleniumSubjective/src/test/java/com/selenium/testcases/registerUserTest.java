package com.selenium.testcases;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.selenium.base.Base;
import com.selenium.utilities.TestUtil;

public class registerUserTest extends Base{
	
	public static void main(String[] args) throws InterruptedException, IOException {
		setUp();
		
		//Thread.sleep(3000);
		
		
		register(driver, "syed", "naser", "1234567891", "someone@gmail.com", "bidar", "bidar", "karnataka", "2546477", "INDIA", "naser123", "naser1234");
		register(driver, "rahul", "khanna", "1234567891", "someone@gmail.com", "bidar", "bidar", "karnataka", "2546477", "INDIA", "naser123", "naser1234");
		
		tearDown();
	}
	public static void register(WebDriver driver, String firstName,String lastName, String phone,String email,String adress,String city,
			String state,String postalCode,String country,String userName,String pass) throws IOException, InterruptedException {
		
			
			driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(firstName);
			driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys(lastName);
			driver.findElement(By.xpath("//input[@name='phone']")).sendKeys(phone);
			driver.findElement(By.xpath("//input[@name='userName']")).sendKeys(email);
			driver.findElement(By.xpath("//input[@name='address1']")).sendKeys(adress);
			driver.findElement(By.xpath("//input[@name='city']")).sendKeys(city);
			driver.findElement(By.xpath("//input[@name='state']")).sendKeys(state);
			driver.findElement(By.xpath("//input[@name='postalCode']")).sendKeys(postalCode);
			WebElement country1 = driver.findElement(By.xpath("//select[@name='country']"));
			country1.click();
			Select sc = new Select(country1);
			sc.selectByValue(country);
			driver.findElement(By.xpath("//input[@name='email']")).sendKeys(userName);
			driver.findElement(By.xpath("//input[@name='password']")).sendKeys(pass);
			driver.findElement(By.xpath("//input[@name='confirmPassword']")).sendKeys(pass);
		
			TestUtil util = new TestUtil();
			TestUtil.captureScreenshot();
			//print coutries	
			List<WebElement> list= driver.findElements(By.xpath("//select//option"));
			int size = list.size();
			for(int i=1;i<=size;i++)
			{
				String str = driver.findElement(By.xpath("//select//option["+i+"]")).getText();
				System.out.println(str);
			}
			WebElement submit = driver.findElement(By.xpath("//input[@name='submit']"));
			submit.click();
			Thread.sleep(4000);
			Assert.assertEquals("Note: Your user name is "+userName+".",driver.findElement(By.xpath("//b[text()=' Note: Your user name is "+userName+".']")).getText());
			TestUtil.captureScreenshot(); 
			System.out.println("Registered successfully");
			driver.get("http://demo.guru99.com/test/newtours/register.php");
			Thread.sleep(3000);
	
}
}
