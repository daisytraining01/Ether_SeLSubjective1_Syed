package com.selenium.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.Hashtable;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.annotations.DataProvider;

import com.selenium.base.Base;

public class TestUtil extends Base {

	public static String screenshotPath;
	public static String screenshotName;

	public static void captureScreenshot() throws IOException {

		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		Date d = new Date();
		screenshotName = d.toString().replace(":", "_").replace(" ", "_") + ".jpg";

		FileUtils.copyFile(scrFile,
				new File(System.getProperty("user.dir") + "\\target\\" + screenshotName));

	}
	public static void writeToExcel(String sheet , int row, int cellnum, String cellValue) throws Throwable {
		Date d = new Date();
		String fileName = d.toString().replace(":", "_").replace(" ", "_");
		Workbook w = new XSSFWorkbook();
		Sheet sheet1 = w.createSheet(sheet);
		Row row1 = sheet1.createRow(row);
		row1.createCell(cellnum).setCellValue(cellValue);
		try {

			// this Writes the workbook

			FileOutputStream out = new FileOutputStream(
					new File(System.getProperty("user.dir") + "\\src\\test\\Links.xlsx"));

			w.write(out);

			out.close();

			System.out.println(fileName + " written successfully on disk.");

		}

		catch (Exception e) {

			e.printStackTrace();

		}
	}
}
